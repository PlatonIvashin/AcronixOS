# AcronixOS

## Главная

Эта сборка вышла под видом ранней поддержки, поэтому эта ОС будет обновляться постепенно,
за всеми подробностями обращаться в дискорд

## Установка

1) Для установки вам потребуется приложения виртулизации (VMWARE/VirtualBox)
Начните установку ОС с яндекс диска
https://disk.yandex.ru/d/OGE6kbf36k0FCg
2) Установите AcronixOS.iso как CD/DVD
3) Установите Filesystem.vdmk как Hard Disk (FAT32)

## Лицензия

https://github.com/pie-with-jam/AcronixOS/blob/main/LICENSE.md
