﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcronixOS.Code.CORE.System32.Configurations
{
    class registry32
    {
        // OS Information
        public static String OS_Version = "1.7";
        public static String OS_Build = "9123";

        // SuperUser
        public static Boolean su = false;
        // registry32
        public static string CurrentDirectory = @"0:\";
    }
}
