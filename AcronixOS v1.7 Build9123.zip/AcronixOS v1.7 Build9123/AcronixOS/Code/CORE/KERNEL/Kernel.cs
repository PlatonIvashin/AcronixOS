﻿using System;
using System.Drawing;
using Sys = Cosmos.System;
using AcronixOS.Code.CORE.terminal;
using AcronixOS.Code.CORE.System32.HARDWARE.FAT;
using AcronixOS.Code.CORE.System32.Configurations;
using Cosmos.System.Graphics;

namespace Graphics
{
    public class Kernel : Sys.Kernel
    {

        protected override void BeforeRun()
        {
            Console.Clear();
            PMFAT.Initialize(); // Инициализация дисковогго пространства
            CommandManager.Initialize(); // Инициализания Терминала
            Console.WriteLine("");
        }

        protected override void Run()
        {
            Console.WriteLine("Welcome to AcronixOS 2023 v" + registry32.OS_Version + " Build " + registry32.OS_Build, Console.ForegroundColor = ConsoleColor.Green);
            Console.Write("To display a list of commands, type: ", Console.ForegroundColor = ConsoleColor.White); Console.WriteLine("HELP", Console.ForegroundColor = ConsoleColor.Green);
            Console.Write("\nWebsite             : ", Console.ForegroundColor = ConsoleColor.White); Console.WriteLine("https://FlyConstant.ruok.org/", Console.ForegroundColor = ConsoleColor.Green);
            Console.Write("AcronixOS Wiki Guide:  ", Console.ForegroundColor = ConsoleColor.White); Console.WriteLine("https://github.com/pie-with-jam/AcronixOS/wiki", Console.ForegroundColor = ConsoleColor.Green);
            Console.Write("AcronixOS Support   :  ", Console.ForegroundColor = ConsoleColor.White); Console.WriteLine("https://github.com/pie-with-jam/AcronixOS/issues \n", Console.ForegroundColor = ConsoleColor.Green);



            CommandManager.GetInput(); // Получение строки терминала
        }
    }
}